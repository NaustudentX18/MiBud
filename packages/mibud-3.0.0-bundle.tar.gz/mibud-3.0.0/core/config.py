"""
MiBud - Configuration Management
Handles all configuration including AI providers, personalities, and settings
"""

import os
import json
from pathlib import Path
from typing import Optional, Dict, Any, List
from dotenv import load_dotenv

# Load environment variables
load_dotenv()


class Config:
    """MiBud Configuration Manager"""
    
    def __init__(self):
        self.config_dir = Path(__file__).parent.parent / "config"
        self.config_file = self.config_dir / "config.json"
        self.profiles_dir = self.config_dir / "profiles"

        # Default configuration
        self.data: Dict[str, Any] = {
            # AI Configuration
            "ai": {
                "default_provider": "openrouter",  # openai, anthropic, google, deepseek, ollama, openrouter
                "offline_provider": "ollama",
                "stt_provider": "whisper_api",  # whisper_api, faster_whisper, vosk
                "tts_provider": "openai_tts",  # openai_tts, piper, coqui, pyttsx3
                "model": "google/gemini-2.0-flash-lite:free",
                "offline_model": "phi-3.5-mini-instruct-q4_k_m.gguf",
                "ollama_url": "http://localhost:11434",
            },
            # Personality
            "personality": {
                "current": "assistant",
                "voice_speed": 1.0,
                "voice_pitch": 1.0,
                "voice_style": "neutral",
            },
            # Wake Word
            "wake_word": {
                "enabled": True,
                "words": ["hey mibud", "ok pi", "hey assistant"],
                "sensitivity": 0.5,
                "use_button": True,
            },
            # Hardware
            "hardware": {
                "display_brightness": 70,
                "display_rotation": 0,
                "audio_input_device": "plughw:1,0",
                "audio_output_device": "default",
                "audio_sample_rate": 16000,
                "enable_led": True,
            },
            # Display
            "display": {
                "theme": "auto",  # auto, dark, light
                "show_clock": True,
                "show_battery": True,
                "show_wifi": True,
                "idle_timeout": 60,
                "sleep_timeout": 300,
            },
            # Network
            "network": {
                "hostname": "mibud",
                "auto_reconnect": True,
            },
            # Features
            "features": {
                "enable_tts": True,
                "enable_stt": True,
                "enable_weather": True,
                "enable_timers": True,
                "enable_home_assistant": False,
                "enable_speaker_recognition": False,
                "enable_anomaly_detection": False,
                "enable_multi_device_sync": False,
                # v2 additions
                "enable_memory": True,
                "enable_tools": True,
                "enable_streaming": True,
                "enable_proactive": True,
                "enable_power_manager": True,
                # v3 additions
                "enable_plugins": False,      # user-owned code; opt-in
                "enable_mcp": False,          # external MCP servers; opt-in
                "enable_trace": True,
                "enable_barge_in": True,
                "enable_continuous_dialog": False,
            },
            # Long-term memory
            "memory": {
                "embedder": "auto",                    # auto | hash | ollama
                "ollama_embed_model": "nomic-embed-text",
                "hash_dim": 256,
                "db_path": "data/memory.db",
                "recall_k": 4,
            },
            # Proactive engine
            "proactive": {
                "battery_enabled": True,
                "reminders_enabled": True,
                "timers_enabled": True,
                "anomaly_enabled": True,
                "idle_checkin_enabled": False,
                "idle_checkin_minutes": 30,
                "morning_greeting_enabled": False,
                "morning_greeting_hour": 7,
                "quiet_hours_start": 23,
                "quiet_hours_end": 7,
            },
            # Power profiles
            "power": {
                "auto": True,
                "eco_below_percent": 25,
                "performance_on_charge": True,
                "manual_profile": "balanced",          # eco | balanced | performance
            },
            # v3: structured conversation trace
            "trace": {
                "path": "data/trace.log",
                "max_bytes": 1 << 20,         # 1 MiB before rotation
                "keep_recent": 200,
            },
            # v3: user-dropped Python plugins
            "plugins": {
                "dir": "plugins",
            },
            # v3: external MCP servers (list of {name, command, args, env, enabled})
            "mcp": {
                "servers": [],
            },
            # v3: dialog session tuning
            "dialog": {
                "continuous": False,
                "continuous_window_s": 8.0,
            },
            # v3: VAD backend selection
            "vad": {
                "backend": "auto",            # auto | rms | silero
                "silero_model_path": "data/silero_vad.onnx",
                "rms_threshold": 500,
            },
            # Schema version for migrations
            "config_version": 3,
            # First run tracking
            "first_run": True,
            "setup_complete": False,
            # Tuning constants — magic numbers externalized here
            "tuning": {
                "conversation_max_history": 10,
                "stt_silence_threshold": 500,
                "stt_max_silence_chunks": 30,
                "vad_threshold": 200,
                "vad_min_trigger_frames": 3,
                "vad_cooldown_seconds": 2.0,
                "battery_low_threshold": 20,
                "battery_critical_threshold": 5,
                "sync_interval_seconds": 30,
                "ai_max_tokens": 500,
                "idle_timeout_seconds": 60,
                "sleep_timeout_seconds": 300,
            },
        }

        # Private secrets — NEVER saved to disk
        self._secrets: Dict[str, str] = {
            "openai": os.getenv("OPENAI_API_KEY", ""),
            "anthropic": os.getenv("ANTHROPIC_API_KEY", ""),
            "google": os.getenv("GOOGLE_API_KEY", ""),
            "deepseek": os.getenv("DEEPSEEK_API_KEY", ""),
            "openrouter": os.getenv("OPENROUTER_API_KEY", ""),
            "elevenlabs": os.getenv("ELEVENLABS_API_KEY", ""),
        }

    def load(self):
        """Load configuration from file"""
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r') as f:
                    saved = json.load(f)
                    saved = self._migrate(saved)
                    self.data.update(saved)
            except Exception as e:
                print(f"Warning: Could not load config: {e}")

    def _migrate(self, saved: Dict[str, Any]) -> Dict[str, Any]:
        """Run migrations from older config versions"""
        version = saved.get("config_version", 0)
        target = self.data.get("config_version", 3)
        while version < target:
            if version == 0:
                saved = self._migrate_v0_to_v1(saved)
                version = 1
            elif version == 1:
                saved = self._migrate_v1_to_v2(saved)
                version = 2
            elif version == 2:
                saved = self._migrate_v2_to_v3(saved)
                version = 3
            else:
                break
        return saved

    def _migrate_v0_to_v1(self, saved: Dict[str, Any]) -> Dict[str, Any]:
        """v0 → v1: add tuning section and config_version"""
        if "tuning" not in saved:
            saved["tuning"] = dict(self.data["tuning"])
        saved["config_version"] = 1
        return saved

    def _migrate_v1_to_v2(self, saved: Dict[str, Any]) -> Dict[str, Any]:
        """v1 → v2: add memory, proactive, power, and new feature flags."""
        features = saved.setdefault("features", {})
        for k, v in self.data["features"].items():
            features.setdefault(k, v)
        for section in ("memory", "proactive", "power"):
            if section not in saved:
                saved[section] = dict(self.data[section])
            else:
                for k, v in self.data[section].items():
                    saved[section].setdefault(k, v)
        saved["config_version"] = 2
        return saved

    def _migrate_v2_to_v3(self, saved: Dict[str, Any]) -> Dict[str, Any]:
        """v2 → v3: add trace, plugins, mcp, dialog, vad sections + v3 feature flags."""
        features = saved.setdefault("features", {})
        for k, v in self.data["features"].items():
            features.setdefault(k, v)
        for section in ("trace", "plugins", "mcp", "dialog", "vad"):
            if section not in saved:
                saved[section] = dict(self.data[section])
            else:
                for k, v in self.data[section].items():
                    saved[section].setdefault(k, v)
        saved["config_version"] = 3
        return saved
                
    def save(self):
        """Save configuration to file"""
        # Strip HA token from persisted data — it lives in .env only
        if "home_assistant" in self.data:
            self.data["home_assistant"] = {
                k: v for k, v in self.data["home_assistant"].items()
                if k != "token"
            }
        self.config_dir.mkdir(parents=True, exist_ok=True)
        save_path = self.config_dir / "config.json"
        with open(save_path, 'w') as f:
            json.dump(self.data, f, indent=2)
            
    def is_first_run(self) -> bool:
        """Check if this is first run"""
        return self.data.get("first_run", True) or not self.data.get("setup_complete", False)
    
    def mark_setup_complete(self):
        """Mark setup as complete"""
        self.data["first_run"] = False
        self.data["setup_complete"] = True
        self.save()
        
    def get(self, key: str, default: Any = None) -> Any:
        """Get config value using dot notation"""
        keys = key.split(".")
        value = self.data
        for k in keys:
            if isinstance(value, dict):
                value = value.get(k)
            else:
                return default
        return value if value is not None else default
    
    def set(self, key: str, value: Any):
        """Set config value using dot notation"""
        keys = key.split(".")
        data = self.data
        for k in keys[:-1]:
            if k not in data:
                data[k] = {}
            data = data[k]
        data[keys[-1]] = value
        
    def get_api_key(self, provider: str) -> str:
        """Get API key for provider. Checks _secrets (runtime) then env vars. Never from disk."""
        key = self._secrets.get(provider, "")
        if not key:
            key = os.getenv(f"{provider.upper()}_API_KEY", "")
        return key

    def has_api_key(self, provider: str) -> bool:
        """Check if API key exists (from env vars only)"""
        key = self.get_api_key(provider)
        return bool(key and key.strip())
    
    def get_all_providers(self) -> List[str]:
        """Get list of configured providers"""
        providers = []
        if self.has_api_key("openai"):
            providers.append("openai")
        if self.has_api_key("anthropic"):
            providers.append("anthropic")
        if self.has_api_key("google"):
            providers.append("google")
        if self.has_api_key("deepseek"):
            providers.append("deepseek")
        if self.has_api_key("openrouter"):
            providers.append("openrouter")
        return providers
        
    def print_summary(self):
        """Print configuration summary"""
        print("\n" + "="*50)
        print("MiBud Configuration Summary")
        print("="*50)
        
        # AI Providers
        print(f"\n🧠 AI Configuration:")
        print(f"   Default Provider: {self.get('ai.default_provider')}")
        print(f"   Model: {self.get('ai.model')}")
        print(f"   Offline Model: {self.get('ai.offline_model')}")
        
        # Providers
        providers = self.get_all_providers()
        print(f"   Configured Providers: {', '.join(providers) if providers else 'None'}")
        
        # Personality
        print(f"\n👤 Personality: {self.get('personality.current')}")
        
        # Wake Word
        ww_enabled = self.get('wake_word.enabled')
        ww_words = self.get('wake_word.words')
        print(f"\n🎤 Wake Word:")
        print(f"   Enabled: {ww_enabled}")
        print(f"   Words: {', '.join(ww_words)}")
        
        # Hardware
        print(f"\n🔧 Hardware:")
        print(f"   Display Brightness: {self.get('hardware.display_brightness')}%")
        print(f"   Audio Input: {self.get('hardware.audio_input_device')}")
        
        # Features
        print(f"\n⚡ Features:")
        print(f"   TTS: {self.get('features.enable_tts')}")
        print(f"   STT: {self.get('features.enable_stt')}")
        print(f"   Weather: {self.get('features.enable_weather')}")
        
        print("\n" + "="*50 + "\n")


# Global config instance
_config: Optional[Config] = None

def get_config() -> Config:
    """Get global config instance"""
    global _config
    if _config is None:
        _config = Config()
        _config.load()
    return _config
